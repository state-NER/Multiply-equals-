class Interpreter:
    def __init__(self, parser):
        self.parser = parser

    def interpret(self):
        ast = self.parser.parse()
        if ast['type'] == 'command':
            self.execute_command(ast['value'])

    def execute_command(self, command):
        if command == '×multiply':
            print("Executing Multiply Equals Command")
