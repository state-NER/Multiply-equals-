import re

class Lexer:
    def __init__(self):
        self.tokens = []
        self.current_position = 0

    def tokenize(self, code):
        token_patterns = [
            (r'×\w+', 'COMMAND'),
            (r'\.', 'DOT'),
            (r'[a-zA-Z_][a-zA-Z0-9_]*', 'ID'),
            (r'[0-9]+', 'NUMBER'),
            (r'[=\(\),;]', 'SYMBOL'),
            (r'[ 	
]+', 'WHITESPACE'),
        ]
        while self.current_position < len(code):
            match = None
            for pattern, token_type in token_patterns:
                regex = re.compile(pattern)
                match = regex.match(code, self.current_position)
                if match:
                    value = match.group(0)
                    if token_type != 'WHITESPACE':
                        self.tokens.append((token_type, value))
                    self.current_position = match.end()
                    break
            if not match:
                raise Exception(f"Invalid character at position {self.current_position}")
        return self.tokens
