class FloID:
    def __init__(self, element_type, attributes):
        self.element_type = element_type
        self.attributes = attributes

    def __str__(self):
        return f"FloID(Type: {self.element_type}, Attributes: {self.attributes})"
