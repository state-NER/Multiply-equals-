class FioID:
    def __init__(self, fid):
        self.fid = fid

    def __str__(self):
        return f"FioID: {self.fid}"
