class VeUID:
    def __init__(self, name, uid):
        self.name = name
        self.uid = uid

    def __str__(self):
        return f"VeUID(Name: {self.name}, UID: {self.uid})"
