class Parser:
    def __init__(self, lexer):
        self.lexer = lexer
        self.tokens = lexer.tokens
        self.current_position = 0

    def parse(self):
        return self.command()

    def command(self):
        if self.current_token()[0] == 'COMMAND':
            command = self.current_token()[1]
            self.consume()
            return {'type': 'command', 'value': command}
        raise Exception("Invalid command syntax.")

    def current_token(self):
        return self.tokens[self.current_position]

    def consume(self):
        self.current_position += 1
