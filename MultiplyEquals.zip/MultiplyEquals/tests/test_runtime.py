import unittest
from language.runtime.ve_uid import VeUID

class TestRuntime(unittest.TestCase):
    def test_ve_uid(self):
        ve_uid = VeUID("button", "12345")
        self.assertEqual(str(ve_uid), "VeUID(Name: button, UID: 12345)")

if __name__ == "__main__":
    unittest.main()
