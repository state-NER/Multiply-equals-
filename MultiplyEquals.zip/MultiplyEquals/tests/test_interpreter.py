import unittest
from language.lexer import Lexer
from language.parser import Parser
from language.interpreter import Interpreter

class TestInterpreter(unittest.TestCase):
    def test_interpreter(self):
        lexer = Lexer()
        tokens = lexer.tokenize('×multiply(.name=hello_world;)')
        parser = Parser(lexer)
        interpreter = Interpreter(parser)
        interpreter.interpret()  # Check if it prints "Executing Multiply Equals Command"

if __name__ == "__main__":
    unittest.main()
