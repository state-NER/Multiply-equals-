import unittest
from language.lexer import Lexer
from language.parser import Parser

class TestParser(unittest.TestCase):
    def test_command_parsing(self):
        lexer = Lexer()
        tokens = lexer.tokenize('×multiply(.name=button_example;)')
        parser = Parser(lexer)
        ast = parser.parse()
        self.assertEqual(ast['type'], 'command')
        self.assertEqual(ast['value'], '×multiply')

if __name__ == "__main__":
    unittest.main()
